import 'dart:math';
import 'package:flutter/material.dart';
import 'generated/formula_engine.g.dart';
import 'local_expression.dart';
import 'math_step_view.dart';

class AdvancedSolverPage extends StatefulWidget {
  const AdvancedSolverPage({super.key});
  @override
  State<AdvancedSolverPage> createState()=>_AdvancedSolverPageState();
}

class _AdvancedSolverPageState extends State<AdvancedSolverPage> {
  String mode='Integral';
  final expression=TextEditingController(text:'sin(x)');
  final first=TextEditingController(text:'0');
  final second=TextEditingController(text:'3.141592653589793');
  final third=TextEditingController(text:'1000');
  List<CalculationStep>? steps;
  String? error;

  double number(TextEditingController c)=>double.parse(c.text.replaceAll(',','.'));
  int integer(TextEditingController c)=>int.parse(c.text);

  void solve() {
    try {
      final f=LocalExpression(expression.text); late List<CalculationStep> value;
      if (mode=='Integral') value=integral(f,number(first),number(second),integer(third));
      else if (mode=='Limite') value=limit(f,number(first));
      else if (mode=='Derivada') value=derivative(f,number(first));
      else value=ode(f,number(first),number(second),number(third),200);
      setState(() { steps=value; error=null; });
    } catch (e) { setState(() { steps=null; error=e.toString().replaceFirst('FormatException: ',''); }); }
  }

  List<CalculationStep> integral(LocalExpression f,double a,double b,int n) {
    if (n<2 || n.isOdd) throw const FormatException('O número de intervalos tem de ser par e igual ou superior a 2.');
    final h=(b-a)/n; double at(double x)=>f.evaluate({'x':x});
    var odd=0.0,even=0.0;
    for (var i=1;i<n;i++) { final y=at(a+i*h); if(i.isOdd) odd+=y; else even+=y; }
    final result=h*(at(a)+at(b)+4*odd+2*even)/3;
    return [
      CalculationStep('1. Definir o integral','∫₍$a₎^($b) (${expression.text}) dx','Integrando e limites confirmados.'),
      CalculationStep('2. Dividir o intervalo','h = ($b − $a) / $n = $h','Regra de Simpson com número par de intervalos.'),
      CalculationStep('3. Somar os termos','h/3 [f₀ + fₙ + 4∑fᵢ ímpar + 2∑fᵢ par]','∑ ímpar=$odd; ∑ par=$even'),
      CalculationStep('4. Resultado','∫ ≈ $result','Resultado numérico calculado localmente.'),
    ];
  }

  List<CalculationStep> limit(LocalExpression f,double point) {
    final eps=[for(var k=2;k<=9;k++) pow(10.0,-k).toDouble()];
    final left=[for(final h in eps) f.evaluate({'x':point-h})];
    final right=[for(final h in eps) f.evaluate({'x':point+h})];
    final l=left.last,r=right.last; final exists=(l-r).abs()<=max(1e-8,max(l.abs(),r.abs())*1e-6);
    return [
      CalculationStep('1. Definir o limite','limₓ→$point ${expression.text}','Ponto confirmado.'),
      CalculationStep('2. Aproximar à esquerda','x → $point⁻; L⁻ ≈ $l',left.toString()),
      CalculationStep('3. Aproximar à direita','x → $point⁺; L⁺ ≈ $r',right.toString()),
      CalculationStep('4. Comparar',exists?'L ≈ ${(l+r)/2}':'Limite bilateral não confirmado','Estimativa numérica local.'),
    ];
  }

  List<CalculationStep> derivative(LocalExpression f,double point) {
    final h=max(1e-5,point.abs()*1e-5); double at(double x)=>f.evaluate({'x':x});
    final result=(at(point-2*h)-8*at(point-h)+8*at(point+h)-at(point+2*h))/(12*h);
    return [
      CalculationStep('1. Definir a função','f(x) = ${expression.text}','Função confirmada.'),
      CalculationStep('2. Aplicar diferença central','f′(x) ≈ [f(x−2h)−8f(x−h)+8f(x+h)−f(x+2h)]/(12h)','h=$h'),
      CalculationStep('3. Resultado','f′($point) ≈ $result','Derivada numérica local.'),
    ];
  }

  List<CalculationStep> ode(LocalExpression f,double x0,double y0,double x1,int n) {
    var x=x0,y=y0; final h=(x1-x0)/n; double at(double xv,double yv)=>f.evaluate({'x':xv,'y':yv});
    for(var i=0;i<n;i++) { final k1=at(x,y),k2=at(x+h/2,y+h*k1/2),k3=at(x+h/2,y+h*k2/2),k4=at(x+h,y+h*k3); y+=h*(k1+2*k2+2*k3+k4)/6; x+=h; }
    return [
      CalculationStep('1. Definir a equação diferencial','dy/dx = ${expression.text}','Usa as variáveis x e y.'),
      CalculationStep('2. Condição inicial','y($x0) = $y0; calcular até x=$x1','Valores confirmados.'),
      CalculationStep('3. Aplicar Runge–Kutta 4','yₙ₊₁ = yₙ + h(k₁+2k₂+2k₃+k₄)/6','n=$n; h=$h'),
      CalculationStep('4. Resultado','y($x) ≈ $y','Solução numérica local.'),
    ];
  }

  @override
  Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Cálculo avançado local')),body:ListView(padding:const EdgeInsets.all(16),children:[
    DropdownButtonFormField<String>(value:mode,items:const [for(final x in ['Integral','Limite','Derivada','Equação diferencial']) DropdownMenuItem(value:x,child:Text(x))],onChanged:(x)=>setState((){mode=x!;steps=null;})),
    const SizedBox(height:12),
    TextField(controller:expression,decoration:InputDecoration(labelText:mode=='Equação diferencial'?'dy/dx = f(x,y)':'Expressão em x',border:const OutlineInputBorder())),
    const SizedBox(height:12),
    TextField(controller:first,decoration:InputDecoration(labelText:mode=='Integral'?'Limite inferior':mode=='Equação diferencial'?'x inicial':'Ponto x',border:const OutlineInputBorder())),
    if(mode=='Integral'||mode=='Equação diferencial') ...[const SizedBox(height:12),TextField(controller:second,decoration:InputDecoration(labelText:mode=='Integral'?'Limite superior':'y inicial',border:const OutlineInputBorder()))],
    if(mode=='Integral'||mode=='Equação diferencial') ...[const SizedBox(height:12),TextField(controller:third,decoration:InputDecoration(labelText:mode=='Integral'?'Intervalos pares':'x final',border:const OutlineInputBorder()))],
    const SizedBox(height:12),FilledButton.icon(onPressed:solve,icon:const Icon(Icons.functions),label:const Text('Resolver localmente')),
    if(error!=null) Padding(padding:const EdgeInsets.only(top:12),child:Text(error!,style:const TextStyle(color:Colors.red))),
    if(steps!=null) Padding(padding:const EdgeInsets.only(top:16),child:MathStepView(steps:steps!,pendingReview:false)),
  ]));
}
