import 'package:flutter/material.dart';
import 'generated/formula_engine.g.dart';
import 'math_step_view.dart';
import 'advanced_solver.dart';
import 'ai_gateway.dart';
import 'vision_theme.dart';

void main() => runApp(const VisionFieldCalcApp());

class VisionFieldCalcApp extends StatelessWidget {
  const VisionFieldCalcApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Vision Field Calc',
    debugShowCheckedModeBanner: false,
    theme: VisionTheme.light,
    home: const CalculatorHome(),
  );
}

class CalculatorHome extends StatefulWidget {
  const CalculatorHome({super.key});
  @override
  State<CalculatorHome> createState() => _CalculatorHomeState();
}

class _CalculatorHomeState extends State<CalculatorHome> {
  late String menu = formulas.first.menu;
  FormulaDefinition? selected;
  final controllers = <String, TextEditingController>{};
  final problemController = TextEditingController();
  LocalCalculation? calculation;
  String? error;
  String? routingMessage;
  AiProposal? aiProposal;
  bool aiBusy = false;

  List<String> get menus => formulas.map((f) => f.menu).toSet().toList();
  List<FormulaDefinition> get visible => formulas.where((f) => f.menu == menu).toList();

  void choose(FormulaDefinition formula) {
    for (final controller in controllers.values) { controller.dispose(); }
    setState(() {
      selected = formula;
      controllers
        ..clear()
        ..addEntries(formula.inputs.map((x) => MapEntry(x, TextEditingController())));
      calculation = null; error = null; routingMessage = null; aiProposal = null;
    });
  }

  void routeProblem() {
    final query = problemController.text.trim().toLowerCase();
    if (query.isEmpty) {
      setState(() => routingMessage = 'Descreva primeiro o cálculo pretendido.');
      return;
    }
    final localMatches = formulas.where((formula) {
      final haystack = '${formula.id} ${formula.name} ${formula.menu}'.toLowerCase();
      return query.split(RegExp(r'\s+')).where((word) => word.length > 2).any(haystack.contains);
    }).toList();
    if (localMatches.isNotEmpty) {
      menu = localMatches.first.menu;
      choose(localMatches.first);
      setState(() => routingMessage = 'Fórmula local encontrada. Confirme os parâmetros e calcule no dispositivo.');
      return;
    }
    setState(() {
      selected = null;
      calculation = null;
      routingMessage = 'O motor local não encontrou uma fórmula. A interpretação por IA requer confirmação dos dados antes de calcular.';
    });
    showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Interpretação por IA'),
      content: const Text('O pedido será enviado ao Vision AI Gateway. A IA propõe a fórmula, variáveis, unidades e hipóteses. Nenhum resultado é aceite até confirmar esses parâmetros.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
        FilledButton(onPressed: () {
          Navigator.pop(dialogContext);
          interpretWithAi(query);
        }, child: const Text('Continuar com IA')),
      ],
    ));
  }

  Future<void> interpretWithAi(String problem) async {
    setState(() { aiBusy = true; aiProposal = null; error = null; });
    try {
      final proposal = await VisionAiGateway().interpret(problem);
      if (!mounted) return;
      final matches = formulas.where((formula) => formula.id == proposal.formulaId).toList();
      if (matches.isNotEmpty) {
        menu = matches.first.menu;
        choose(matches.first);
      }
      setState(() {
        aiProposal = proposal;
        routingMessage = 'Proposta da IA recebida. Confirme fórmula, variáveis, unidades e hipóteses antes de calcular.';
      });
    } catch (exception) {
      if (!mounted) return;
      setState(() => error = exception.toString().replaceFirst('Bad state: ', ''));
    } finally {
      if (mounted) setState(() => aiBusy = false);
    }
  }

  @override
  void dispose() {
    for (final controller in controllers.values) { controller.dispose(); }
    problemController.dispose();
    super.dispose();
  }

  void calculate() {
    final formula = selected;
    if (formula == null) return;
    try {
      final values = <String, double>{
        for (final item in controllers.entries) item.key: double.parse(item.value.text.replaceAll(',', '.')),
      };
      setState(() { calculation = calculateFormula(formula, values); error = null; });
    } catch (exception) {
      setState(() { calculation = null; error = exception.toString().replaceFirst('FormatException: ', ''); });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Vision Field Calc'), actions: [
      IconButton(tooltip: 'Integrais, limites, derivadas e equações diferenciais', icon: const Icon(Icons.functions),
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AdvancedSolverPage()))),
    ]),
    body: LayoutBuilder(builder: (context, size) {
      final narrow = size.maxWidth < 820;
      final catalog = _catalogPanel();
      final work = _workPanel();
      return narrow ? ListView(children: [catalog, work]) : Row(children: [SizedBox(width: 360, child: catalog), Expanded(child: work)]);
    }),
  );

  Widget _catalogPanel() => Card(margin: const EdgeInsets.all(12), child: Padding(
    padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('Menu de cálculos', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      const SizedBox(height: 8),
      TextField(
        controller: problemController,
        decoration: const InputDecoration(
          labelText: 'Descreva o cálculo',
          hintText: 'Ex.: área de um círculo ou queda de tensão trifásica',
          border: OutlineInputBorder(),
        ),
        onSubmitted: (_) => routeProblem(),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: routeProblem,
        icon: const Icon(Icons.route),
        label: const Text('Procurar primeiro no motor local'),
      ),
      if (routingMessage != null) Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Text(routingMessage!),
      ),
      if (aiBusy) const Padding(
        padding: EdgeInsets.only(top: 8),
        child: LinearProgressIndicator(),
      ),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: menu, items: [for (final value in menus) DropdownMenuItem(value: value, child: Text(value))],
        onChanged: (value) { if (value != null) setState(() { menu=value; selected=null; calculation=null; }); }),
      const SizedBox(height: 8),
      for (final formula in visible)
        ListTile(selected: selected?.id == formula.id, title: Text(formula.name), subtitle: Text(prettyMath(formula.expression)), onTap: () => choose(formula)),
    ]),
  ));

  Widget _workPanel() {
    final formula=selected;
    if (formula == null) return ListView(padding: const EdgeInsets.all(24), children: [
      const Text('Escolha uma fórmula ou descreva o problema.', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      const SelectableText('Notação visual: ∫  ∑  π  σ  μ  Δ  θ  λ  ρ  ω  x  y  dy/dx', style: TextStyle(fontSize: 20, fontFamily: 'serif')),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
      if (aiProposal != null) _aiProposalCard(aiProposal!),
    ]);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(formula.name, style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 6),
      SelectableText(prettyMath(formula.expression), style: const TextStyle(fontSize: 24, fontFamily: 'serif')),
      const SizedBox(height: 8),
      const Card(
        child: Padding(
          padding: EdgeInsets.all(12),
          child: SelectableText(
            'Notação visual: ∫ integral · ∑ somatório · π · σ · μ · Δ · θ · λ · ρ · ω · x · y · dy/dx',
            style: TextStyle(fontSize: 18, fontFamily: 'serif'),
          ),
        ),
      ),
      const SizedBox(height: 16),
      for (final input in formula.inputs) Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(
        controller: controllers[input], keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
        decoration: InputDecoration(labelText: input, border: const OutlineInputBorder()),
      )),
      FilledButton.icon(onPressed: calculate, icon: const Icon(Icons.calculate), label: const Text('Calcular localmente')),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
      if (calculation != null) Padding(padding: const EdgeInsets.only(top: 16), child: MathStepView(
        steps: calculation!.steps, pendingReview: formula.status != 'implemented')),
      const SizedBox(height: 16),
      const Text('A aplicação tenta sempre o cálculo local. Se não houver solução local, a IA pode apenas propor fórmula, variáveis, unidades e hipóteses; o utilizador confirma tudo antes do cálculo.'),
      if (aiProposal != null) _aiProposalCard(aiProposal!),
    ]);
  }

  Widget _aiProposalCard(AiProposal proposal) => Card(
    margin: const EdgeInsets.only(top: 16),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Proposta da IA — confirmar antes de calcular', style: TextStyle(fontWeight: FontWeight.bold)),
        if (proposal.displayMath.isNotEmpty) SelectableText(proposal.displayMath, style: const TextStyle(fontSize: 22, fontFamily: 'serif')),
        Text('Variáveis: ${proposal.variables}'),
        Text('Unidades: ${proposal.units}'),
        if (proposal.assumptions.isNotEmpty) Text("Hipóteses: ${proposal.assumptions.join('; ')}"),
        for (var index = 0; index < proposal.explanationSteps.length; index++)
          ListTile(
            dense: true,
            leading: CircleAvatar(child: Text('${index + 1}')),
            title: SelectableText(proposal.explanationSteps[index]),
          ),
        const Text('Confirme ou corrija estes dados antes de executar o cálculo local.'),
      ]),
    ),
  );
}
