import 'package:flutter/material.dart';
import 'generated/formula_engine.g.dart';

class MathStepView extends StatelessWidget {
  final List<CalculationStep> steps;
  final bool pendingReview;
  const MathStepView({super.key, required this.steps, required this.pendingReview});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (pendingReview)
        const Card(color: Color(0xfffff3cd), child: Padding(
          padding: EdgeInsets.all(12),
          child: Text('Cálculo funcional. Validação técnica ou certificação pendente; confirme norma, edição, hipóteses e fatores antes de uma decisão real.'),
        )),
      for (final step in steps)
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(step.title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            SelectableText(step.mathematics, style: const TextStyle(fontSize: 20, fontFamily: 'serif')),
            const SizedBox(height: 6),
            Text(step.explanation),
          ],
        ))),
      const Card(child: Padding(
        padding: EdgeInsets.all(16),
        child: SelectableText('Notação suportada no ecrã: ∫  ∑  π  σ  μ  Δ  θ  λ  ρ  ω  x  y  dy/dx',
          style: TextStyle(fontSize: 20, fontFamily: 'serif')),
      )),
    ]);
  }
}
