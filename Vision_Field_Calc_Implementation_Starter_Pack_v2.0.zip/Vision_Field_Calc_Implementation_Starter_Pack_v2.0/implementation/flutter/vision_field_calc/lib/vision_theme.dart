import 'package:flutter/material.dart';

class VisionTheme {
  static const canvas = Color(0xFFFDFCFC);
  static const panel = Color(0xFFF5F3F1);
  static const white = Color(0xFFFFFFFF);
  static const black = Color(0xFF000000);
  static const mutedText = Color(0xFF5F5F5F);
  static const subtleBorder = Color(0x13000000);

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        fontFamily: 'Inter',
        scaffoldBackgroundColor: canvas,
        colorScheme: const ColorScheme.light(
          primary: black,
          onPrimary: white,
          secondary: black,
          onSecondary: white,
          surface: canvas,
          onSurface: black,
          outline: subtleBorder,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: canvas,
          foregroundColor: black,
          elevation: 0,
          surfaceTintColor: Colors.transparent,
          titleTextStyle: TextStyle(
            color: black,
            fontFamily: 'Inter',
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        cardTheme: CardThemeData(
          color: panel,
          elevation: 0,
          surfaceTintColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: const BorderSide(color: subtleBorder, width: 0.5),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: black,
            foregroundColor: white,
            minimumSize: const Size(44, 44),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: const StadiumBorder(),
            textStyle: const TextStyle(fontSize: 14, height: 1.5),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            backgroundColor: white,
            foregroundColor: black,
            minimumSize: const Size(44, 44),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            side: const BorderSide(color: subtleBorder, width: 0.5),
            shape: const StadiumBorder(),
            textStyle: const TextStyle(fontSize: 14, height: 1.5),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: subtleBorder, width: 0.5),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: subtleBorder, width: 0.5),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: black, width: 1.25),
          ),
        ),
        textTheme: const TextTheme(
          displayLarge: TextStyle(fontSize: 48, height: 52 / 48, fontWeight: FontWeight.w300, letterSpacing: -0.96),
          headlineSmall: TextStyle(fontSize: 28, height: 1.15, fontWeight: FontWeight.w400, letterSpacing: -0.4),
          titleLarge: TextStyle(fontSize: 20, height: 1.3, fontWeight: FontWeight.w500),
          titleMedium: TextStyle(fontSize: 18, height: 1.4, fontWeight: FontWeight.w500),
          bodyLarge: TextStyle(fontSize: 18, height: 1.6, fontWeight: FontWeight.w400),
          bodyMedium: TextStyle(fontSize: 16, height: 1.5, fontWeight: FontWeight.w400),
          labelLarge: TextStyle(fontSize: 14, height: 1.5, fontWeight: FontWeight.w400),
        ),
      );
}
